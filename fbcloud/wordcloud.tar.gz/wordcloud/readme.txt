Thank you for downloading the Lots of Code PHP wordCloud.

--

The required file structure is as follows:

Example file, contains a list of example ways to include the script.
> ./example.php 

Stylesheet, contains all the size options, imported in example.php
> ./css/wordcloud.css 

PHP Class, included in example.php
> ./classes/wordcloud.class.php

--

If you have any problems, use our support forum: http://www.lotsofcode.com/forum/

If you would like to comment on the script, please do so here: http://www.lotsofcode.com/php/tutorials/tag-cloud-v2

--

Thanks again,
www.lotsofcode.com