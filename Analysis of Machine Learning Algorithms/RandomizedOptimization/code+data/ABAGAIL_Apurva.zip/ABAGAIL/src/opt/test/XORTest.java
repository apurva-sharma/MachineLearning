package opt.test;

import util.linalg.Vector;
//import java.util.Vector;
import ann.CSVadapter;
import ann.CsvDataset;
import opt.OptimizationAlgorithm;
import opt.RandomizedHillClimbing;
import opt.example.NeuralNetworkOptimizationProblem;
import shared.DataSet;
import shared.DataSetReader;
import shared.ErrorMeasure;
import shared.FixedIterationTrainer;
import shared.Instance;
import shared.SumOfSquaresError;
import func.nn.backprop.BackPropagationNetwork;
import func.nn.backprop.BackPropagationNetworkFactory;

/**
 * Test optimization for neural networks
 * @author Andrew Guillory gtg008g@mail.gatech.edu
 * @version 1.0
 */
public class XORTest {
    
    /**
     * Tests out the perceptron with the classic xor test
     * @param args ignored
     */
    public static void main(String[] args) {
        BackPropagationNetworkFactory factory = 
            new BackPropagationNetworkFactory();
      /*  	double[][][] data = {
               { { 1, 1, 1, 1 }, { 0 } },
               { { 1, 0, 1, 0 }, { 1 } },
               { { 0, 1, 0, 1 }, { 1 } },
               { { 0, 0, 0, 0 }, { 0 } }
        };*/
  /*     System.out.println(">>>>>>>>>>>"+data.length); 
       System.out.println(data[0][0][0]);
       System.out.println(data[0][0][1]);
       System.out.println(data[0][0][2]);
       System.out.println(data[0][0][3]);*/
      // System.out.println(data[0][0][4]);
       //System.out.println(data[0][1][0]);
       //System.out.println(data[0][1][1]);
        
        double [][][] data = null;
        //data[0]={{1,1},{0}};
     //   double data1[][][]=new double[10][10][1];
        
        
        
        
        
        
        
        DataSetReader dataReader = new DataSetReader("/home/apurva/Desktop/sem2/ml/assignment2/spambase1.csv");
		double[][][] data2 = data;
		try {
			DataSet examples = dataReader.read();
			System.out.println("EXAMPLES::" + examples.get(0) );
			System.out.println(examples.get(0).getData());
			Vector y;
			
			y=examples.get(0).getData();
			System.out.println("^^^^^"+ y.get(0));
			int cnt=0;
			for (int j=0;j<1;j++)
			{
				for(int i=0;i<y.size();i++)
				{
					for (int k=0;k<y.size();k++)
					{
						data2[j][i][k]=y.get(cnt);
						cnt++;
					}
				//data[j][i]=y.get(i);
				}
			}
			System.out.println(data2[0][0][0]);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

		//This helps discretize the data
		CSVadapter adapter = new CSVadapter();
		CsvDataset csvData = adapter.readData("/home/apurva/Desktop/sem2/ml/assignment2/spambase1.csv");

        Instance[] patterns = new Instance[data2.length];
        for (int i = 0; i < patterns.length; i++) {
            patterns[i] = new Instance(data2[i][0]);
            patterns[i].setLabel(new Instance(data2[i][1]));
        }
        BackPropagationNetwork network = factory.createClassificationNetwork(
           new int[] { 4, 3, 1 });
        ErrorMeasure measure = new SumOfSquaresError();
        DataSet set = new DataSet(patterns);
        NeuralNetworkOptimizationProblem nno = new NeuralNetworkOptimizationProblem(
            set, network, measure);
        OptimizationAlgorithm o = new RandomizedHillClimbing(nno);
        FixedIterationTrainer fit = new FixedIterationTrainer(o, 5000);
        fit.train();
        Instance opt = o.getOptimal();
        network.setWeights(opt.getData());
        for (int i = 0; i < patterns.length; i++) {
            network.setInputValues(patterns[i].getData());
            network.run();
            System.out.println("~~");
            System.out.println(patterns[i].getLabel());
            System.out.println(network.getOutputValues());
        }
    } 

}
