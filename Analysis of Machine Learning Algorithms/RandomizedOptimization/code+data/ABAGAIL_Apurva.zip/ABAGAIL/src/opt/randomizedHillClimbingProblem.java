package opt;

import shared.Instance;

public class randomizedHillClimbingProblem implements HillClimbingProblem {

	public randomizedHillClimbingProblem() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Instance neighbor(Instance d) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Instance random() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double value(Instance d) {
		// TODO Auto-generated method stub
		return 0;
	}

}
