package assignment2;

import opt.HillClimbingProblem;
import opt.example.KnapsackEvaluationFunction;
import shared.Instance;

public class OptimizedKnapSackProblem extends KnapsackEvaluationFunction
        implements HillClimbingProblem {

    public OptimizedKnapSackProblem(double[] w, double[] v, double maxV,
            int[] maxC) {
        super(w, v, maxV, maxC);
        // TODO Auto-generated constructor stub
    }

    /* (non-Javadoc)
     * @see opt.HillClimbingProblem#neighbor(shared.Instance)
     */
    @Override
    public Instance neighbor(Instance d) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see opt.OptimizationProblem#random()
     */
    @Override
    public Instance random() {
        // TODO Auto-generated method stub
        return null;
    }
    
    public Instance solve(){
        /***
         * Create instance of RandomizedHillClimbing.java by passing this object
         * RandomizedHillClimbing rhc = new RandomizedHillClimbing(this);
         * do{
         *     rhc.train()
         * }while optimum value is not reached
         *
         *
         * call
         */
        
        return null;
    }

    /***
     * In the main method,
     * create an instance of OptimizedKnapsackProblem (set the constructor values)
     * call OKP.solve
     *
     */
}