	
package ann;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import csvUtil.com.CsvReader;

public class CSVadapter 
{

	public CsvDataset readData(String filePath)
	{
		CsvDataset data = null;

		try 
		{
			data = new CsvDataset();
			CsvReader csvReader = new CsvReader(filePath);

			/*data.headers = csvReader.getHeaders();
			data.headerCount = data.headers.length;*/
			String[] values = null;
			
			List row = null;
			int counter = 1;

			while(csvReader.readRecord())
			{
				row = new ArrayList();
				
				//values = csvReader.getValues();
				
				for(int i = 0; i < csvReader.getColumnCount(); i++)
				{
					row.add(Float.valueOf(csvReader.get(i)));
				}
				counter++;
				data.rows.add(row);
			}
			data.headerCount = row.size();
			System.out.println("total rows read = " + --counter);
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		catch (IOException e)
		{
			e.printStackTrace();
			System.out.println(e);
		}

		return data;
	}

	
	/**
	 * This function returns the labels assigned to continuous data
	 * based on how many classes are requested for in the divisions variable
	 * @param divisions - the number of classes to divide the data into
	 * @param data - the data to classify
	 */
	public int[] addClassificationAndDiscretize(int divisions, CsvDataset data)
	{
		int[] lables = new int[data.rows.size()];
		System.out.println(lables.length + " the size of lables");
		
		if(divisions < 2)
		{
			System.out.println("Error! enter atleast 2 or more divisions.. ");
			 return null;
		}

		List<Float> tempRow = new ArrayList<Float>();

		//Find min and max ranges for the entire data range..
		Float max = Float.MIN_NORMAL;
		Float min = Float.MAX_VALUE;

		for (int i = 0; i < data.rows.size(); i++) 
		{
			tempRow = (List<Float>) data.rows.get(i);

			if(tempRow.get(data.headerCount - 1) < min)
			{
				min = tempRow.get(data.headerCount - 1);
			}

			if(tempRow.get(data.headerCount - 1) > max)
			{
				max = tempRow.get(data.headerCount - 1);
			}
		}
		
		System.out.println(min + " is the minimum value of the classifying attribute, and the max is " + max);

		//adding equal classification over the range of the last attribute
		if(divisions == 2)
		{
			Float range = min + (max - min) / 2;

			for (int i = 0; i < data.rows.size(); i++) 
			{
				tempRow = (List<Float>) data.rows.get(i);

				if(tempRow.get(data.headerCount - 1) <= range)
				{
					lables[i] = 0;
				}
				else
				{
					lables[i] = 1;
				}
			}
		}
		else
		{
			Float interval = (max - min)/divisions;
			Float rangeMin = Float.MIN_NORMAL;
			Float rangeMax = min + interval;

			for (int j = 0; j < divisions; j++) 
			{
				for (int i = 0; i < data.rows.size(); i++) 
				{
					tempRow = (List<Float>) data.rows.get(i);

					if(tempRow.get(data.headerCount - 1) > rangeMin && tempRow.get(data.headerCount - 1) <= rangeMax)
					{
						data.rows.set(i, tempRow);
						lables[i] = j;
					}
				}

				rangeMin = rangeMax;
				rangeMax = (rangeMax + interval >= max) ? Float.MAX_VALUE : (rangeMax + interval);
			}
		}
		
		//lables contains the vector of lables allotted to the entire range of the data
		return lables;
	}
	
	/**
	 * This function writes the labels assigned to continuous data
	 * based on how many classes are requested for in the divisions variable to the data in memory
	 * @param divisions - the number of classes to divide the data into
	 * @param data - the data to classify
	 */
	public int[] addClassificationAndDiscretizeInMemory(int divisions, CsvDataset data)
	{
		int[] lables = new int[data.rows.size()];
		
		if(divisions < 2)
		{
			System.out.println("Error! enter atleast 2 or more divisions.. ");
			 return null;
		}

		List<Float> tempRow = new ArrayList<Float>();

		//Find min and max ranges for the entire data range..
		Float max = Float.MIN_NORMAL;
		Float min = Float.MAX_VALUE;

		for (int i = 0; i < data.rows.size(); i++) 
		{
			tempRow = (List<Float>) data.rows.get(i);

			if(tempRow.get(data.headerCount - 1) < min)
			{
				min = tempRow.get(data.headerCount - 1);
			}

			if(tempRow.get(data.headerCount - 1) > max)
			{
				max = tempRow.get(data.headerCount - 1);
			}
		}

		//adding equal classification over the range of the last attribute
		if(divisions == 2)
		{
			Float range = min + (max - min) / 2;

			for (int i = 0; i < data.rows.size(); i++) 
			{
				tempRow = (List<Float>) data.rows.get(i);

				if(tempRow.get(data.headerCount - 1) <= range)
				{
					tempRow.add(0f);
					lables[i] = 0;
				}
				else
				{
					tempRow.add(1f);
					lables[i] = 1;
				}

				data.rows.set(i, tempRow);
			}
		}
		else
		{
			Float interval = (max - min)/divisions;
			Float rangeMin = Float.MIN_NORMAL;
			Float rangeMax = min + interval;

			for (int j = 0; j < divisions; j++) 
			{
				for (int i = 0; i < data.rows.size(); i++) 
				{
					tempRow = (List<Float>) data.rows.get(i);

					if(tempRow.get(data.headerCount - 1) > rangeMin && tempRow.get(data.headerCount - 1) <= rangeMax)
					{
						tempRow.add((float)j);
						data.rows.set(i, tempRow);
						
						lables[i] = j;
					}
				}

				rangeMin = rangeMax;
				rangeMax = (rangeMax + interval >= max) ? Float.MAX_VALUE : (rangeMax + interval);
			}
		}
		
		//lables contains the vector of lables allotted to the entire range of the data
		return lables;
	}
}
