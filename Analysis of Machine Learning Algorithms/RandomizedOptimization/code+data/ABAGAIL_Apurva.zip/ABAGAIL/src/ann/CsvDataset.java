package ann;

import java.util.ArrayList;
import java.util.List;

public class CsvDataset 
{
	public String headers[];
	public int headerCount;
	
	public List rows = new ArrayList();
}
