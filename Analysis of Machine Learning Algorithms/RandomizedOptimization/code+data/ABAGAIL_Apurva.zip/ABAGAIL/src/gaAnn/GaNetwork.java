package gaAnn;

import java.io.PrintStream;
import java.util.Random;

import ann.CSVadapter;
import ann.CsvDataset;

import shared.DataSet;
import shared.DataSetReader;
import shared.Instance;
import util.linalg.Vector;
import func.nn.FeedForwardLayer;
import func.nn.FeedForwardNetwork;
import func.nn.FeedForwardNode;
import func.nn.Layer;
import func.nn.Neuron;
import func.nn.activation.ActivationFunction;
import func.nn.activation.LogisticSigmoid;

public class GaNetwork 
{

	public static void main(String[] args)
	{
		try 
		{
			//System.setOut(new PrintStream("/home/apurva/Desktop/ml/assignment2/Gan_output_100_iter.txt"));
			String opfile_path=args[1];
			System.setOut(new PrintStream(opfile_path));
			//The data to be used.. Need to change the datareader to be able to read the csv files
			DataSetReader dataReader = new DataSetReader("/home/apurva/Desktop/sem2/ml/assignment2/spambase1.csv");
			DataSet examples = dataReader.read();

			//This helps discretize the data
			CSVadapter adapter = new CSVadapter();
			CsvDataset csvData = adapter.readData("/home/apurva/Desktop/sem2/ml/assignment2/spambase1.csv");


			//These labels are indexed according to the row index of the input data
			int[] lables = adapter.addClassificationAndDiscretize(2, csvData);

			Instance inputInstance = examples.get(0);

			//Should be minus 1, change later
			int inputLayerSize = inputInstance.size() - 1;

			//System.out.println("Size of input layer - " + inputLayerSize);

			//The network we use is a feedforward network
			FeedForwardNetwork network = new FeedForwardNetwork();

			FeedForwardLayer inputLayer = new FeedForwardLayer();

			FeedForwardNode node;
			LogisticSigmoid sigmoid = new LogisticSigmoid();

			//Create the input layer
			for(int i = 0; i <= inputLayerSize ; i++)
			{
				node = new FeedForwardNode(sigmoid);
				inputLayer.addNode(node);
			}

			FeedForwardLayer hiddenLayer = new FeedForwardLayer();

			//Create the hidden layer
			for(int i = 0; i < 10; i++)
			{
				node = new FeedForwardNode(sigmoid);
				hiddenLayer.addNode(node);
			}
			
			/*
			FeedForwardLayer hiddenLayer1 = new FeedForwardLayer();
			for(int i = 0; i < 10; i++)
			{
				node = new FeedForwardNode(sigmoid);
				hiddenLayer1.addNode(node);
			}
			
			FeedForwardLayer hiddenLayer2 = new FeedForwardLayer();
			for(int i = 0; i < 5; i++)
			{
				node = new FeedForwardNode(sigmoid);
				hiddenLayer2.addNode(node);
			}
			
			FeedForwardLayer hiddenLayer3 = new FeedForwardLayer();
			for(int i = 0; i < 4; i++)
			{
				node = new FeedForwardNode(sigmoid);
				hiddenLayer3.addNode(node);
			}
			
			FeedForwardLayer hiddenLayer4 = new FeedForwardLayer();
			for(int i = 0; i < 3; i++)
			{
				node = new FeedForwardNode(sigmoid);
				hiddenLayer4.addNode(node);
			}
			*/
			
			FeedForwardLayer outputLayer = new FeedForwardLayer();

			//Create the output layer
			for(int i = 0; i < 2; i++)
			{
				node = new FeedForwardNode(sigmoid);
				outputLayer.addNode(node);
			}

			//Connect all the layers
			inputLayer.connect(hiddenLayer);
		/*	hiddenLayer.connect(hiddenLayer1);
			hiddenLayer1.connect(hiddenLayer2);
			hiddenLayer2.connect(hiddenLayer3);
			hiddenLayer3.connect(hiddenLayer4);*/
			hiddenLayer.connect(outputLayer);

			//Adding the layers the network
			network.setInputLayer(inputLayer);
			network.addHiddenLayer(hiddenLayer);
		/*	network.addHiddenLayer(hiddenLayer1);
			network.addHiddenLayer(hiddenLayer2);
			network.addHiddenLayer(hiddenLayer3);
			network.addHiddenLayer(hiddenLayer4);*/
			network.setOutputLayer(outputLayer);

			//Holds the total number of weights used by the network
			int networkWeightsLength = network.getWeights().length;

			//Define the population
			double population[][][] = new double[10][10][networkWeightsLength];
			int bestPopIndex = 0;
			
			//Define population score
			double scores[][] = null;

			//Score of the entire population
			double[] popScore = new double[10];

			Random rand = new Random();

			//generate random populations method call
			generateRandomPopulation(population,networkWeightsLength,rand);

			//System.out.println("the number of weights" + network.getWeights().length);

			

			int iterations = 0;
			int exampleSize = examples.size();
			boolean done = false;
			int maxIterations = Integer.parseInt(args[0]);
			while(!done && iterations <= maxIterations)
			{
				scores = new double[10][10];
				
				//Now run the network on the input values
				for(int i=0;i<10;i++) //level a
				{
					for(int j=0;j<10;j++) //level b
					{
						//set weight for each member of the population
						network.setWeights(population[i][j]);

						for(int k=0;k<exampleSize;k++)
						{
							//Iterate over the various rows of the data, get vectors from 0 to inputlayersize -1, since last element is the class attrib
							network.setInputValues(examples.get(k).getData().get(0,inputLayerSize - 1));
							
							//run the network on these weights
							network.run();

							Vector outputVector = network.getOutputValues();

							//Replace 0 later by the index of the row of the data
							scores[i][j] += (1 - outputVector.get(lables[k]))/exampleSize;
						}
						
					//	System.out.println("Score is " + scores[i][j]);
					}

					sortPopulation(population[i], scores[i]);
					popScore[i] = populationFitness(scores[i]);
					
					//Do mutations and crossovers
					/*
					 * First 3 crossovers
					 */
					for(int j = 0;j<2;j++)
					//for(int j = 0;j<3;j++)
					{
						crossover(population[i][j],population[i][j+1],(rand.nextInt()%population[i][j].length));
					}
					/*
					 * Next 4 mutations
					 */
					for(int j = 3;j<7;j++)
					//for(int j = 3;j<7;j++)
					{
						mutate(population[i][j], Math.abs((rand.nextInt()%population[i][j].length)),rand);
					}
					/*
					 * Next 3 die and are randomly regenerated
					 */
					for(int j = 3;j<7;j++)
					//for(int j = 7;j<10;j++)
					{
						for(int k=0;k<networkWeightsLength;k++)
						{
							population[i][j][k] = rand.nextGaussian();
							if(rand.nextFloat() > 0.5)
							{
								population[i][j][k] *= -1;
							}
						}
					}


					//System.out.println("populations sorted-");
					//System.out.println("---------------------------------------------------------------------------------------------------- \n");

				}
				
				scores = null;

				for(int i=0;i<10;i++)
				{
					
					if(popScore[i]<=0.05)
					{
						System.out.println("popscore is " + popScore[i]);
						//System.out.println("We have a good population");
						System.out.println("Total iterations are :  "  + iterations);
						done = true;
						bestPopIndex = i;
						break;
					}
				}
				
				iterations++;
			}
		//	System.out.println("Total iterations are :  "  + --iterations);

			int classificationErrors = 0;
			int correctClassifications = 0;
			network.setWeights(population[bestPopIndex][0]);
			//Verification
		//	System.out.println("best population was " + bestPopIndex);
			for(int m = 0; m < lables.length; m++)
			{
				network.setInputValues(examples.get(m).getData().get(0,inputLayerSize - 1));
				
				//run the network on these weights
				network.run();

				Vector outputVector = network.getOutputValues();
				
			//	System.out.println("Predicted = " + outputVector.argMax() + "  label was " + lables[m]);
				
				if (outputVector.argMax()==lables[m])
				{
					correctClassifications++;
				}
				else
				{
					classificationErrors++;
				}
				
/*				for (int d = 0; d < outputVector.size(); d++) 
				{
					System.out.println(outputVector.get(d));
				}*/
				//System.exit(0);
			}//end while
			System.out.println("Correctly classified "+ correctClassifications);
			System.out.println("Clasfified wrongly" + classificationErrors);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//end exception
	}//end method

	private static double populationFitness(double[] scores) 
	{
		double sum = 0d;
		for (int i = 0; i < 4; i++) 
		{
			sum += scores[i]/4;
		}

		return sum;
	}

	private static void generateRandomPopulation(double[][][] population, int networkWeightsLength, Random rand)
	{
		//Generate the random population
		for(int i=0;i<10;i++)
		{
			for(int j=0;j<10;j++)
			{
				for(int k=0;k<networkWeightsLength;k++)
				{
					population[i][j][k] = rand.nextGaussian();
					if(rand.nextFloat() > 0.5)
					{
						population[i][j][k] *= -1;
					}
				}
			}
		}
	}

	private static void sortPopulation(double[][] population, double[] scores)
	{
		double[] temp;
		double tempscore;

		for(int i=0;i<population.length;i++)
		{
			for(int j=0;j<population.length;j++)
			{
				if(scores[i] < scores[j])
				{
					tempscore = scores[i];
					scores[i] = scores[j];
					scores[j] = tempscore;

					temp = population[i];
					population[i] = population[j];
					population[j] = temp;
				}
			}
		}
	}

	private static void crossover(double[] populationOne, double[] populationTwo, int crossPoint)
	{
		double[] tempA = new double[populationOne.length], tempB = new double[populationTwo.length];

		for(int i=0;i<populationTwo.length;i++)
		{
			if(i<=crossPoint)
			{
				tempA[i] = populationOne[i];
				tempB[i] = populationTwo[i];
			}
			else
			{
				tempA[i] = populationTwo[i];
				tempB[i] = populationOne[i];
			}

		}
		populationOne = tempA;
		populationTwo = tempB;
	}

	public static void mutate(double[] population, int mutationPoint, Random rand)
	{
		for (int i = mutationPoint ; i < population.length ; i++ )
		{
			population[i]= rand.nextGaussian();
			if(rand.nextGaussian()<0.5)
			{
				population[i] *= -1;
			}
		}
	}
}
