package saANN;

import java.io.PrintStream;
import java.util.Random;

import opt.ContinuousAddOneNeighbor;
import shared.DataSet;
import shared.DataSetReader;
import shared.Instance;
import util.linalg.Vector;
import ann.CSVadapter;
import ann.CsvDataset;
import func.nn.FeedForwardLayer;
import func.nn.FeedForwardNetwork;
import func.nn.FeedForwardNode;
import func.nn.activation.LogisticSigmoid;

public class SAAnn 
{
	public static void main(String[] args) 
	{

		try {

			/*System.setOut(new PrintStream("/home/apurva/Desktop/output.txt"));*/
			String opfile_path=args[1];
			//System.setOut(new PrintStream(opfile_path));

			//Temperature
			double temperature = 10d;

			//Anneal
			boolean anneal = true;

			//The data to be used.. Need to change the datareader to be able to read the csv files
			DataSetReader dataReader = new DataSetReader("/home/apurva/Desktop/sem2/ml/assignment2/spambase1.csv");
			DataSet examples = dataReader.read();


			//This helps discretize the data
			CSVadapter adapter = new CSVadapter();
			CsvDataset csvData = adapter.readData("/home/apurva/Desktop/sem2/ml/assignment2/spambase1.csv");

			//Continuous neighbor generation
			ContinuousAddOneNeighbor continuousNeighbor = new ContinuousAddOneNeighbor();

			//These lables are indexed according to the row index of the input data
			int[] lables = adapter.addClassificationAndDiscretize(2, csvData);

			Instance inputInstance = examples.get(0);

			//Should be minus 1, since ignoring the classification attribute (last attribute)
			int inputLayerSize = inputInstance.size() - 1;

			//System.out.println("Size of input layer ---  " + inputLayerSize);

			//The network we use is a feedforward network
			FeedForwardNetwork network = new FeedForwardNetwork();

			FeedForwardLayer inputLayer = new FeedForwardLayer();

			FeedForwardNode node;
			LogisticSigmoid sigmoid = new LogisticSigmoid();

			//Create the input layer
			for(int i = 0; i < inputLayerSize; i++)
			{
				node = new FeedForwardNode(sigmoid);
				inputLayer.addNode(node);
			}

			FeedForwardLayer hiddenLayerA = new FeedForwardLayer();

			//Create the hidden layer
			for(int i = 0; i < 4; i++)
			{
				node = new FeedForwardNode(sigmoid);
				hiddenLayerA.addNode(node);
			}

			FeedForwardLayer hiddenLayerB = new FeedForwardLayer();

			//Create the hidden layer
			for(int i = 0; i < 4; i++)
			{
				node = new FeedForwardNode(sigmoid);
				hiddenLayerB.addNode(node);
			}

			FeedForwardLayer outputLayer = new FeedForwardLayer();

			//Create the output layer
			for(int i = 0; i < 2; i++)
			{
				node = new FeedForwardNode(sigmoid);
				outputLayer.addNode(node);
			}

			//Connect all the layers
			inputLayer.connect(hiddenLayerB);
			//hiddenLayerA.connect(hiddenLayerB);
			hiddenLayerB.connect(outputLayer);

			//Adding the layers the network
			network.setInputLayer(inputLayer);
			//network.addHiddenLayer(hiddenLayerA);
			network.addHiddenLayer(hiddenLayerB);
			network.setOutputLayer(outputLayer);

			network.connect();

			//Holds the total number of weights used by the network
			int networkWeightsLength = network.getWeights().length;

			//Best state double vector
			double stateVector[] = new double[networkWeightsLength];
			//Define the temporal double vector
			double newVector[] = new double[networkWeightsLength];

			//Score of the entire population
			double stateScore = Double.MAX_VALUE;
			double newScore = 0d;

			Random rand = new Random();

			//generate random populations method call
			generateRandomVector(newVector,rand);
			/*for(int i=0;i<newVector.length;i++)
				System.out.println(newVector[i]);*/

			//System.out.println("`````````````````````````````````````````````````````");
			network.setWeights(newVector);
			/*for(int i=0;i<network.getWeights().length;i++)
				System.out.println(network.getWeights()[i]);*/


//			System.out.println("the number of weights" + network.getWeights().length);

			int iterations = 0;
			int exampleSize = examples.size();
			boolean done = false;
			int classificationErrors = 0;
			int correctClassifications = 0;
			int maxIterations = Integer.parseInt(args[0]);
			while(!done && iterations < maxIterations)
			{

				//set weight for each member of the population
				network.setWeights(newVector);
				
				for(int k=0;k<exampleSize;k++)
				{
					//Iterate over the various rows of the data, get vectors from 0 to inputlayersize -1, since last element is the class attrib
					network.setInputValues(examples.get(k).getData().get(0,inputLayerSize-1));

					//run the network on these weights
					network.run();

					Vector outputVector = network.getOutputValues();

					for(int vectorIndex = 0; vectorIndex < outputVector.size(); vectorIndex++)
					{
						if(vectorIndex == lables[k])
						{
							//if(!(outputVector.argMax() == lables[k]))
							{
								newScore += Math.pow(
										(1 - outputVector.get(vectorIndex)/exampleSize),
										2);
							}
						}
						else
						{
							newScore += Math.pow(
									(0 - outputVector.get(vectorIndex)/exampleSize),
									2);
						}

						/*//Replace 0 later by the index of the row of the data
						if((outputVector.argMax() == vectorIndex) && !(outputVector.argMax() == lables[k]))
						{
							System.out.println("**  " + (1 - outputVector.get(lables[k])));
							newScore += Math.pow((1 - outputVector.get(lables[k]))/exampleSize,2);
						}
						else if(vectorIndex == lables[k])
						{

						}*/
					}

				}
				//System.out.println("new score " + newScore +"   old score " + stateScore);
				//if(anneal(newScore,stateScore,(double)100/(iterations+1)) < rand.nextDouble())
				//vary cooling rate
				if(anneal(newScore,stateScore,(double)100/(iterations*20)) < rand.nextDouble())
				{
					if(newScore < stateScore)
					{
						stateScore = newScore;
						for(int f=0;f<newVector.length;f++)
						{
							stateVector[f] = newVector[f];
					//		System.out.println("saving vector" + stateVector[f]);
						}
					}
				}

				newScore = 0d;
				//Now generate the new vector in the space..
				//generateRandomVector(newVector, rand);

				//Try using continuous one neighbor to get new neighbor weights
				Instance neighbor = continuousNeighbor.neighbor(new Instance(newVector));
				for(int j=0;j<neighbor.size();j++)
				{
					newVector[j] = neighbor.getData().get(j); 
				}


				if(stateScore <= 0.01)
				{
					System.out.println("We have a good population");
					System.out.println("Total iterations are :  "  + iterations);
					done = true;
				}

				iterations++;
			}
			System.out.println("Total iterations " + --iterations);
			System.out.println("Final score " + stateScore);

			//System.out.println("---------------------");
			/*for(int p = 0; p < stateVector.length; p++)
			{
				System.out.println(stateVector[p]);
			}
			System.out.println("---------------------");*/

			network.setWeights(stateVector);
			//Verification
			double tpscore = 0;
			
			for(int m = 0; m < exampleSize; m++)
			{
				network.setInputValues(examples.get(m).getData().get(0,inputLayerSize - 1));

				//run the network on these weights
				network.run();

				Vector outputVector = network.getOutputValues();
				
				if (outputVector.argMax()==lables[m])
				{
					correctClassifications++;
				}
				else
				{
					classificationErrors++;
				}

				//System.out.println("Predicted = " + outputVector.argMax() + "  label was " + lables[m]);

				/*for (int d = 0; d < outputVector.size(); d++) 
				{
					System.out.println(outputVector.get(d));
				}*/

				tpscore += (1 - outputVector.get(lables[m]))/exampleSize;
				//				System.out.println("**  " + (1 - outputVector.get(lables[m]))/exampleSize);
			}

			System.out.println(" the avg score is " + tpscore);
			System.out.println("Correctly classified "+ correctClassifications);
			System.out.println("Clasfified wrongly" + classificationErrors);

		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static double anneal(double newScore, double stateScore, double i) 
	{
		double annealingFactor = newScore - stateScore;

		annealingFactor /= i;

		annealingFactor = Math.exp(annealingFactor);
		
		return annealingFactor;
	}

	/**
	 * This method generates the random weight vector for starting the search
	 * @param weightVector represents a neural network state
	 * @param rand the random number generator
	 */
	private static void generateRandomVector(double[] weightVector, Random rand) 
	{
		for (int i = 0; i < weightVector.length; i++) 
		{
			weightVector[i] = rand.nextDouble();
			weightVector[i] *= rand.nextDouble() < 0.5 ? -1 : 1;
		}
	}
}
